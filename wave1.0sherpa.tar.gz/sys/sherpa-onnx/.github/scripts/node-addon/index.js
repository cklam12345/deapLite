module.exports = require('./sherpa-onnx.node');
