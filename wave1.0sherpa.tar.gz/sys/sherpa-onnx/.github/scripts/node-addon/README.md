# Introduction

Please see
https://github.com/k2-fsa/sherpa-onnx/blob/master/nodejs-addon-examples/README.md
for usages.


||Method|Support multiple threads|Minimum required node version|
|---|---|---|---|
|this package| https://github.com/nodejs/node-addon-api | Yes | v16|
|https://www.npmjs.com/package/sherpa-onnx| WebAssembly | No | v18|
