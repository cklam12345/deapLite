# Introduction

See also

  - https://github.com/WonderInventions/node-webrtc/blob/develop/package.json
  - https://stackoverflow.com/questions/15176082/npm-package-json-os-specific-dependency
  - https://github.com/WonderInventions/node-webrtc/blob/develop/lib/binding.js
  - cross-compiling https://github.com/nodejs/node-gyp/issues/829#issuecomment-665527032
  - https://nodejs.github.io/node-addon-examples/build-tools/cmake-js
