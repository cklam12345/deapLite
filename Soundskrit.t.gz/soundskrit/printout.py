import sounddevice as sd
import numpy as np
import wave
import time
import os
import threading
import queue
devices = sd.query_devices()
print(devices)