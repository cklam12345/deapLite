import asyncio
import wave
import os
from datetime import datetime
from bleak import BleakClient, BleakScanner
import opuslib
from flask import Flask, request, jsonify

# ... (Device and Audio settings - same as before)
# Device settings
DEVICE_NAME = "Friend"

SERVICE_UUID = "19b10000-e8f2-537e-4f6c-d104768a1214"
AUDIO_DATA_STREAM_UUID = "19b10001-e8f2-537e-4f6c-d104768a1214"
AUDIO_CODEC_UUID = "19b10002-e8f2-537e-4f6c-d104768a1214"

# Audio settings
SAMPLE_RATE = 16000  # Adjust as per your device's specifications
CHANNELS = 1  # Adjust as per your device's specifications
SAMPLE_WIDTH = 2  # Adjust as per your device's specifications
RECORD_DIR = "records"

if not os.path.exists(RECORD_DIR):
    os.makedirs(RECORD_DIR)


audio_frames = []
recording = False
client_global = None
device_global = None
chunk_duration = 10  # Duration of each audio chunk in seconds

app = Flask(__name__)
loop = asyncio.get_event_loop()

# ... (FrameProcessor class - same as before)
class FrameProcessor:
    def __init__(self, sample_rate, channels):
        self.opus_decoder = opuslib.Decoder(sample_rate, channels)
        self.last_packet_index = -1
        self.last_frame_id = -1
        self.pending = bytearray()
        self.lost = 0

    def store_frame_packet(self, data):
        index = data[0] + (data[1] << 8)
        internal = data[2]
        content = data[3:]

        if self.last_packet_index == -1 and internal == 0:
            self.last_packet_index = index
            self.last_frame_id = internal
            self.pending = content
            return

        if self.last_packet_index == -1:
            return

        if index != self.last_packet_index + 1 or (
            internal != 0 and internal != self.last_frame_id + 1
        ):
            print("Lost frame")
            self.last_packet_index = -1
            self.pending = bytearray()
            self.lost += 1
            return

        if internal == 0:
            audio_frames.append(self.pending)  # Save frame
            self.pending = content  # Start new frame
            self.last_frame_id = internal  # Update internal frame id
            self.last_packet_index = index  # Update packet id
            return

        self.pending.extend(content)
        self.last_frame_id = internal  # Update internal frame id
        self.last_packet_index = index  # Update packet id

    def decode_frames(self):
        pcm_data = bytearray()
        frame_size = 960  # Adjust frame size as per Opus settings (e.g., 960 for 20ms frames at 48kHz)

        for frame in audio_frames:
            try:
                decoded_frame = self.opus_decoder.decode(bytes(frame), frame_size)
                pcm_data.extend(decoded_frame)
            except Exception as e:
                print(f"Error decoding frame: {e}")
        return pcm_data

frame_processor = FrameProcessor(SAMPLE_RATE, CHANNELS)

async def find_device_by_name(name=DEVICE_NAME):
    # ... (same as before)

    while True:
        devices = await BleakScanner.discover()

        if not devices:
            print("No Bluetooth devices found. Retrying...")
            await asyncio.sleep(5)  # Wait for 5 seconds before retrying
            continue

        print("Found devices:")
        for device in devices:
            if device.name and name.lower() in device.name.lower():
                if device.name.strip():  # Ensure the device name is not blank
                    print(f"Name: {device.name}, Address: {device.address}")
                    return device

        print(f"Device with name '{name}' not found. Retrying...")
        await asyncio.sleep(5)  # Wait for 5 seconds before retrying

async def connect_to_device(device):
    global client_global, device_global
    device_global = device
    def disconnect_handler(client):
        print("Device disconnected")
        if recording:
            stop_recording() # Save any remaining data
        device_global = None
        client_global = None

    async with BleakClient(device, disconnected_callback=disconnect_handler) as client:
        client_global = client
        print(f"Connected: {client.is_connected}")

        def audio_data_handler(sender, data):
            if recording:
                frame_processor.store_frame_packet(data)

        await client.start_notify(AUDIO_DATA_STREAM_UUID, audio_data_handler)
        print("Started audio data notification.")

        try:
            while client.is_connected:
                if recording: # Check recording status within the loop
                    await asyncio.sleep(chunk_duration)
                    save_audio_chunk() # Save a chunk of audio
                else:
                    await asyncio.sleep(1) # Small sleep when not recording
        except asyncio.CancelledError:
            print("Connection task cancelled.")
        finally:
            print("Stopping notification and disconnecting...")
            if client.is_connected:
                await client.stop_notify(AUDIO_DATA_STREAM_UUID)
                await client.disconnect()
            print("Disconnected successfully")
            client_global = None
            device_global = None

def save_audio_chunk():
    global audio_frames
    pcm_data = frame_processor.decode_frames()
    frame_processor.pending = bytearray()
    audio_frames = []

    if pcm_data:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        audio_file = os.path.join(RECORD_DIR, f"{timestamp}.wav")
        with wave.open(audio_file, "wb") as wf:
            wf.setnchannels(CHANNELS)
            wf.setsampwidth(SAMPLE_WIDTH)
            wf.setframerate(SAMPLE_RATE)
            wf.writeframes(pcm_data)
        print(f"Audio chunk saved to {audio_file}")

@app.route('/start_recording', methods=['POST'])
async def start_recording_route():
    global recording, device_global
    if not device_global:
        device_global = await find_device_by_name()
        if device_global is None:
            return jsonify({"error": "Device not found"}), 404
        loop.create_task(connect_to_device(device_global))
        while client_global is None or not client_global.is_connected:
            await asyncio.sleep(0.1)
    recording = True
    return jsonify({"message": "Recording started"}), 200

@app.route('/stop_recording', methods=['POST'])
def stop_recording_route():
    global recording
    recording = False
    save_audio_chunk() #Save any remaining data
    if client_global and client_global.is_connected:
        loop.create_task(client_global.disconnect())
    return jsonify({"message": "Recording stopped"}), 200

# ... (status route and main function - same as before)
@app.route('/status', methods=['GET'])
def status_route():
    return jsonify({"recording": recording}), 200

async def main():
    # This now just starts the Flask app
    app.run(host='0.0.0.0', port=5005)

if __name__ == '__main__':
    try:
        loop.run_until_complete(main())
    except KeyboardInterrupt:
        print("Program interrupted by user, shutting down...")
    finally:
        if client_global and client_global.is_connected:
            loop.run_until_complete(client_global.disconnect())
        loop.close()